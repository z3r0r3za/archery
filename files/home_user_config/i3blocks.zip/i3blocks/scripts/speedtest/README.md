# speedtest
Shows the results of testing your bandwidth with speedtest-cli

![](speedtest.png)

# Requirements
Dependencies: bash, speedtest-cli

Suggested: fonts-font-awesome

# Usage
Just change the `interval=300` line in your config to decide the amount of time between each test.
Please note that, due to the nature of the speed test, the first time you will execute it, it will take a while 
for the block to appear (it has to gather the result from `speedtest-cli` first)
A version in which the test will be triggered by clicking the block, as well as customizable colors, will
follow soon.
